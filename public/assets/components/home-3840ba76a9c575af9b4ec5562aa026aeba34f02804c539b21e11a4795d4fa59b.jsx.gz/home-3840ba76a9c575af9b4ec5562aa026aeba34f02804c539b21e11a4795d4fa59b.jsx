class Home extends React.Component {
  render () {
    return (
      <h2>
        Title within React
      </h2>
    );
  }
}
